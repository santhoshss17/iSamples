//
//  BTCNotificationWindow.h
//  SS Growl
//
//  Created by iSamples on 11/02/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface SSNotificationWindow : NSWindow {
@private
    NSPoint initialLocation;

}

@end
